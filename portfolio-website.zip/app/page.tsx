import { ProfileCard } from "@/components/profile-card"
import { AboutSection } from "@/components/about-section"
import { SkillsSection } from "@/components/skills-section"
import { ServicesSection } from "@/components/services-section"
import { ProjectsSection } from "@/components/projects-section"
import { ConceptCard } from "@/components/concept-card"
import { ContactForm } from "@/components/contact-form"
import { LocationSection } from "@/components/location-section"

export default function PortfolioPage() {
  return (
    <main className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Section - 2 columns on large screens */}
          <div className="lg:col-span-2 space-y-6">
            {/* Top row with profile and about */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <ProfileCard />
              <AboutSection />
            </div>

            {/* Skills Section */}
            <SkillsSection />

            {/* Services Section */}
            <ServicesSection />

            {/* Projects Section */}
            <ProjectsSection />
          </div>

          {/* Right Section - 1 column on large screens */}
          <div className="space-y-6">
            <ConceptCard />
            <ContactForm />
            <LocationSection />
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-12 text-center">
          <p className="text-sm text-muted-foreground">© 2026 Hasibur Rahman. All rights reserved.</p>
        </footer>
      </div>
    </main>
  )
}
