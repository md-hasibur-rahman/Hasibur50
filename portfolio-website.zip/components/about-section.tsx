import { User } from "lucide-react"

export function AboutSection() {
  return (
    <div className="bg-card rounded-2xl p-6 shadow-sm border border-border">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <User className="w-4 h-4 text-primary" />
        </div>
        <h2 className="text-lg font-semibold text-card-foreground">About Me</h2>
      </div>
      <p className="text-muted-foreground text-sm leading-relaxed">
        I'm a passionate web developer with expertise in building modern, responsive web applications. I love turning
        complex problems into simple, beautiful, and intuitive designs. With a strong foundation in frontend
        technologies and a keen eye for detail, I strive to create exceptional digital experiences.
      </p>
    </div>
  )
}
