export function ProfileCard() {
  return (
    <div className="bg-card rounded-2xl p-6 shadow-sm border border-border">
      <div className="flex flex-col items-center text-center">
        <div className="w-28 h-28 rounded-full bg-secondary flex items-center justify-center mb-4 overflow-hidden">
          <img src="/professional-male-developer.png" alt="Hasibur Rahman" className="w-full h-full object-cover" />
        </div>
        <h1 className="text-xl font-semibold text-card-foreground mb-2">Hi, I am Hasibur Rahman</h1>
        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-primary text-primary-foreground">
          Web Developer
        </span>
      </div>
    </div>
  )
}
