import { ExternalLink } from "lucide-react"

const projects = [
  {
    title: "E-Commerce Platform",
    image: "/modern-ecommerce-dashboard.png",
  },
  {
    title: "Task Management App",
    image: "/task-management-app.png",
  },
  {
    title: "Portfolio Website",
    image: "/creative-portfolio-website.png",
  },
  {
    title: "Blog Platform",
    image: "/modern-blog-platform.png",
  },
]

export function ProjectsSection() {
  return (
    <div className="bg-card rounded-2xl p-6 shadow-sm border border-border">
      <h2 className="text-lg font-semibold text-card-foreground mb-4">My Projects</h2>
      <div className="grid grid-cols-2 gap-4">
        {projects.map((project) => (
          <div key={project.title} className="group relative rounded-xl overflow-hidden cursor-pointer">
            <img
              src={project.image || "/placeholder.svg"}
              alt={project.title}
              className="w-full h-32 object-cover transition-transform duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
              <div className="p-3 w-full">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-primary-foreground">{project.title}</span>
                  <ExternalLink className="w-4 h-4 text-primary-foreground" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
