import { Code, Palette, Smartphone, Globe } from "lucide-react"

const services = [
  {
    icon: Code,
    title: "Web Development",
    description: "Building responsive and performant web applications",
  },
  {
    icon: Palette,
    title: "UI/UX Design",
    description: "Creating intuitive and beautiful user interfaces",
  },
  {
    icon: Smartphone,
    title: "Mobile Responsive",
    description: "Ensuring seamless experience across all devices",
  },
  {
    icon: Globe,
    title: "SEO Optimization",
    description: "Improving visibility and search engine rankings",
  },
]

export function ServicesSection() {
  return (
    <div className="bg-card rounded-2xl p-6 shadow-sm border border-border">
      <h2 className="text-lg font-semibold text-card-foreground mb-4">What I Do</h2>
      <div className="grid grid-cols-2 gap-3">
        {services.map((service) => (
          <div
            key={service.title}
            className="p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors group cursor-default"
          >
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
              <service.icon className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-sm font-medium text-card-foreground mb-1">{service.title}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">{service.description}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
