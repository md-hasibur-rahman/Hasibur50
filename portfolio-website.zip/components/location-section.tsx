import { MapPin } from "lucide-react"

export function LocationSection() {
  return (
    <div className="bg-card rounded-2xl p-6 shadow-sm border border-border">
      <h2 className="text-lg font-semibold text-card-foreground mb-4">My Location</h2>
      <div className="rounded-xl overflow-hidden mb-4 bg-secondary">
        <img src="/map-location-dhaka-bangladesh.jpg" alt="Location Map" className="w-full h-44 object-cover" />
      </div>
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
          <MapPin className="w-4 h-4 text-primary" />
        </div>
        <div>
          <p className="text-sm font-medium text-card-foreground">Dhaka, Bangladesh</p>
          <p className="text-xs text-muted-foreground mt-0.5">123 Developer Street, Tech District</p>
        </div>
      </div>
    </div>
  )
}
