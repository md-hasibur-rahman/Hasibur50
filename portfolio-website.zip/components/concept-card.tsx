import { Smartphone, Smile, MessageCircle } from "lucide-react"

const concepts = [
  { label: "Sim", value: "+880 1XXX-XXXXXX", icon: Smartphone },
  { label: "Emoji", value: "😊 🚀 💻", icon: Smile },
  { label: "WhatsApp", value: "+880 1XXX-XXXXXX", icon: MessageCircle },
]

export function ConceptCard() {
  return (
    <div className="bg-card rounded-2xl p-6 shadow-sm border border-border">
      <h2 className="text-lg font-semibold text-card-foreground mb-4">Concept</h2>
      <div className="space-y-3">
        {concepts.map((concept) => (
          <div
            key={concept.label}
            className="flex items-center gap-3 p-3 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors"
          >
            <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
              <concept.icon className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{concept.label}</p>
              <p className="text-sm font-medium text-card-foreground">{concept.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
